package com.orbita.umtoque;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
